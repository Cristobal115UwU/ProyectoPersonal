
--INSERCIONES DE CLIENTES--

INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'Juan67', '1q2w3e', 'AKDBYW7382937', '5558093480', 'Juan', 'Ramirez', 'Perez');

INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'Pedro9', 'contraseña', 'LAIDHEOQ890G6', '9284729408', 'Pedro', 'Valeriano', 'Flores');

INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'Maria23', 'maria0109', 'OFAKDBHSYTOJD', '9954872988', 'Maria', 'Ramirez', 'Perez');

INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'Felipe', 'contra99', 'ALSHBDMAIYGAK', '5582010469', 'Brandon', 'Cervantes', 'Rubi');

INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'ManoloSmn', 'simon44', 'PA8WHRYSI7PSJ', '5500274898', 'Manolo', 'Alvarez', 'Sanchez');



--INSERCIONES DE LA DIRECCION DE LOS CLIENTES

INSERT INTO cliente_direccion (direccion_id, direccion, cliente_id)
	values(nextval('cliente_direccion_pk_seq'), 'El clavelero #255, col. Benito Juarez cd Nezahualcoyotl', 1);
INSERT INTO cliente_direccion (direccion_id, direccion, cliente_id)
	values(nextval('cliente_direccion_pk_seq'), 'Toltecas #87, col. La Aurora, Coyoacan', 4);
INSERT INTO cliente_direccion (direccion_id, direccion, cliente_id)
	values(nextval('cliente_direccion_pk_seq'), 'Pajaro Azul #355, col. Benito Juarez cd Nezahualcoyotl', 2);
INSERT INTO cliente_direccion (direccion_id, direccion, cliente_id)
	values(nextval('cliente_direccion_pk_seq'), '4ta avenida #48, col. Benito Juarez cd Nezahualcoyotl', 3);
INSERT INTO cliente_direccion (direccion_id, direccion, cliente_id)
	values(nextval('cliente_direccion_pk_seq'), 'El clavelero #99, Aztecas Coyoacan', 5);

--INSERCIONES DE LA DIRECCION DE LOS TIPO_FORMA_PAGO

INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave1', 'Tarjeta de Credito', 'Tarjeta VISA', 'T');--
INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave2', 'Tarjeta de Credito', 'Tarjeta MasterCard', 'T');
INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave3', 'Pago en Efectivo', 'Efectivo VISA', 'E');--
INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave4', 'Clave Interbancaria', 'Clave INBURSA VISA', 'B');--
INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave5', 'Tarjeta de Credito', 'Tarjeta MasterCard', 'T');--

--INSERCIONES DE LA DIRECCION DE LOS CLIENTE_FORMA_PAGO

INSERT INTO cliente_forma_pago (cliente_forma_pago_id, num_tarjeta, fecha_expriracion, cliente_id, tipo_forma_pago_id)
	values (nextval('cliente_forma_pago_pk_seq'), '9273 0184 9988 2037', to_date('01/09/2024', 'MM/YY'), 2, 1); --Encomtramos que Posgresql no soporta fechas con ese formato, tienen que estar completas
														--Asi no marca error, pero tampoco lo hace
INSERT INTO cliente_forma_pago (cliente_forma_pago_id, clabe, cliente_id, tipo_forma_pago_id)
	values (nextval('cliente_forma_pago_pk_seq'), '0921392384023940239', 4, 4);
INSERT INTO cliente_forma_pago (cliente_forma_pago_id, num_tarjeta, fecha_expriracion, cliente_id, tipo_forma_pago_id)
	values (nextval('cliente_forma_pago_pk_seq'), '0934 9238 1173 8739', to_date('01/09/2026', 'MM/YY'), 1, 5);
INSERT INTO cliente_forma_pago (cliente_forma_pago_id, cliente_id, tipo_forma_pago_id)
	values (nextval('cliente_forma_pago_pk_seq'), 5, 3);
INSERT INTO cliente_forma_pago (cliente_forma_pago_id, num_tarjeta, fecha_expriracion, cliente_id, tipo_forma_pago_id)
	values (nextval('cliente_forma_pago_pk_seq'), '9273 0184 9988 2037',  to_date('01/04/2026', 'MM/YY'), 3, 2);


--INSERCIONES DE LA DIRECCION DE LOS STATUS_COMPRA

INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'R', 'Orden generada', '1');
INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'S', 'Streaming habilitado', '1');
INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'P', 'Orden pagada', '1');
INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'C', 'Orden cancelada', '0');
INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'E', 'Orden entregada', '0');

--INSERCIONES DE ORDEN

INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAAAAAAA1', 3, 1);
INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAAAAAAA2', 1, 4);
INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAAAAAAA3', 4, 3);
INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAAAAAAA4', 2, 5);
INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAAAAAAA5', 5, 2);

--INSERCIONES DE HISTORIAL PARA EL STATUS DE COMPRA

INSERT INTO historico_status_compra (historico_status_compra_id, fecha_status, status_compra_id, orden_id)
	values(nextval('historico_status_compra_pk_seq'), current_date, 1, 4);
INSERT INTO historico_status_compra (historico_status_compra_id, fecha_status, status_compra_id, orden_id)
	values(nextval('historico_status_compra_pk_seq'), current_date, 2, 2);
INSERT INTO historico_status_compra (historico_status_compra_id, fecha_status, status_compra_id, orden_id)
	values(nextval('historico_status_compra_pk_seq'), current_date, 3, 5);
INSERT INTO historico_status_compra (historico_status_compra_id, fecha_status, status_compra_id, orden_id)
	values(nextval('historico_status_compra_pk_seq'), current_date, 4, 1);
INSERT INTO historico_status_compra (historico_status_compra_id, fecha_status, status_compra_id, orden_id)
	values(nextval('historico_status_compra_pk_seq'), current_date, 5, 3);

--INSERCIONES DE FACTURA
--Hay que arreglar los precios de fatura
INSERT INTO factura(factura_id, fecha_generacion, total, iva, folio, orden_id, cliente_forma_pago_id)
	values(nextval('factura_pk_seq'), current_date, 1500, 1500*0.16, '0000000001', 4, 1);
INSERT INTO factura(factura_id, fecha_generacion, total, iva, folio, orden_id, cliente_forma_pago_id)
	values(nextval('factura_pk_seq'), current_date, 6000, 6000*0.16, '0000000002', 1, 4);
INSERT INTO factura(factura_id, fecha_generacion, total, iva, folio, orden_id, cliente_forma_pago_id)
	values(nextval('factura_pk_seq'), current_date, 19500, 19500*0.16, '0000000003', 5, 2);
INSERT INTO factura(factura_id, fecha_generacion, total, iva, folio, orden_id, cliente_forma_pago_id)
	values(nextval('factura_pk_seq'), current_date, 150, 150*0.16, '0000000004', 2, 3);
INSERT INTO factura(factura_id, fecha_generacion, total, iva, folio, orden_id, cliente_forma_pago_id)
	values(nextval('factura_pk_seq'), current_date, 2000, 2000*0.16, '0000000005', 3, 5);

--INSERCIONES DE PRODUCTO 

INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'P', 'PPPPPPPPP1', 150, 0, 1);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'V', 'VVVVVVVVV2', 1500, 1, 0);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'A', 'AAAAAAAAA3', 700, 1, 1);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'P', 'PPPPPPPPP4', 250, 1, 1);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico, promocion_id)
	values(nextval('producto_pk_seq'), 'V', 'VVVVVVVVV5', 1600, 0, 1, 2);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'P', 'PPPPPPPPP4', 200, 1, 1);
INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'A', 'AAAAAAAAA3', 1200, 1, 1);

--INSERCIONES DE EMPRESA

INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'DHL', 'DHL01', 'A');
INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'FEDEX', 'FEDEX01', 'A');
INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'FEDEX', 'FEDEX02', 'B');
INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'CORREOS DE MEXICO', 'CORREOS01', 'C');
INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'DHL', 'DHL02', 'B');

--INSERCIONES DE PAQUETE

INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '9823 0983 0111 0192 9384', 1.5, current_date, '50x30x10', 1, 4);
INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '2534 5653 3457 5689 2325', 5.5, current_date, '50x50x30', 3, 1);
INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '0923 4829 2942 2094 9383', 0.5, current_date, '20x10x10', 2, 5);
INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '3937 2422 3569 2920 2094', 3.45, current_date, '40x20x50', 5, 2);
INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '0923 9800 9273 9183 2312', 1.2, current_date, '50x30x10', 4, 3);

--INSERCIONES DE PRODUCTO_ORDEN

INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 150, 1, 1, 4);
INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 1600, 3, 5, 1);
INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 700, 1, 3, 3);
INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 250, 5, 4, 5);
INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 1600, 1, 5, 2);

--INSERCIONES DE STREAMING 

INSERT INTO streaming (producto_id, URL, reproducciones)
	values(2, 'www.misStreamings.com', 56);
INSERT INTO streaming (producto_id, URL, reproducciones)
	values(3, 'www.iVirtualStream.com', 1200);
INSERT INTO streaming (producto_id, URL, reproducciones)
	values(4, 'www.iVirtualStream.com', 99);
INSERT INTO streaming (producto_id, URL, reproducciones)
	values(6, 'www.misStreamings.com', 678);
INSERT INTO streaming (producto_id, URL, reproducciones)
	values(7, 'www.iVirtualStream.com', 920);

--INSERCIONES DE FISICO 

INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(1, 7, 93, 0);
INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(3, 12, 88, 2);
INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(4, 4, 96, 0);
INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(5, 22, 78, 1);
INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(6, 9, 91, 0);
INSERT INTO fisico (producto_id, copias_vendidas, copias_existencia, copias_defectuosas)
	values(7, 1, 99, 0);

--INSERCIONES DE VIDEOJUEGOS

INSERT INTO videojuego (producto_id, nombre, descripcion, tipo_consola)
	values(2, 'Gears of War', 'Shooter 3ra persona', 'Xbox-Windows');
INSERT INTO videojuego (producto_id, nombre, descripcion, tipo_consola)
	values(5, 'Minecraft', 'Lo mejor de la vida', 'Xbox-Windows-movil-switch-ps4');

--INSERCIONES DE PELICULAS

INSERT INTO pelicula (producto_id, nombre, genero, duracion, clasificacion, formato_video)
	values(1, 'Coraline', 'Animacion', 101, 'A', 'HD 1080p');
INSERT INTO pelicula (producto_id, nombre, genero, duracion, clasificacion, formato_video)
	values(4, 'Mulan', 'Animacion', 88, 'A', 'HD 1080p');
INSERT INTO pelicula (producto_id, nombre, genero, duracion, clasificacion, formato_video)
	values(6, 'The babadook', 'Suspenso', 113, 'B', 'HD 1080p');

--INSERCIONES DE ALBUM 3 7

INSERT INTO album_musical (producto_id, autor, nombre, año_creacion, disquera)
	values(3, 'Modest Mouse', 'No One is First, And You are Next', 2009, 'Epic Records');
INSERT INTO album_musical (producto_id, autor, nombre, año_creacion, disquera)
	values(7, 'The Wrecks', 'We Are The Wrecks', 2017, 'Another Century');

--INSERCIONES DE ESCALA
--Aqui no se si vayamos a tener problemas con que tenga sentido
INSERT INTO escala (paquete_id, numero_escala, lugar, fecha_hora_arrivo)
	values(3, 000001, 'Coacalco de Berriozabal, MX', current_date);
INSERT INTO escala (paquete_id, numero_escala, lugar, fecha_hora_arrivo)
	values(5, 000005, 'Tultitlan, El Fresco, MX', current_date);
INSERT INTO escala (paquete_id, numero_escala, lugar, fecha_hora_arrivo)
	values(2, 000003, 'Lerdo, TX, US', current_date);
INSERT INTO escala (paquete_id, numero_escala, lugar, fecha_hora_arrivo)
	values(4, 000001, 'Ciudad Nezahualcoyotl, Mx', current_date);
INSERT INTO escala (paquete_id, numero_escala, lugar, fecha_hora_arrivo)
	values(1, 000002, 'Coacalco de Berriozabal, Mx', current_date);











