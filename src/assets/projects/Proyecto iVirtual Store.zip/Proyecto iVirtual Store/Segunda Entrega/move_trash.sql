

DROP TABLE cliente;
DROP TABLE cliente_direccion;
DROP TABLE tipo_forma_pago;
DROP TABLE cliente_forma_pago;
DROP TABLE status_compra;
DROP TABLE orden;
DROP TABLE historico_status_compra;
DROP TABLE factura;
DROP TABLE producto;
DROP TABLE empresa;
DROP TABLE paquete;
DROP TABLE producto_orden;
DROP TABLE streaming;
DROP TABLE fisico;
DROP TABLE videojuego;
DROP TABLE album_musical;
DROP TABLE pelicula;
DROP TABLE escala;

DROP SEQUENCE cliente_pk_seq;
DROP SEQUENCE cliente_direccion_pk_seq;
DROP SEQUENCE tipo_forma_pago_pk_seq;
DROP SEQUENCE cliente_forma_pago_pk_seq;
DROP SEQUENCE status_compra_pk_seq;
DROP SEQUENCE orden_pk_seq;
DROP SEQUENCE historico_status_compra_pk_seq;
DROP SEQUENCE factura_pk_seq;
DROP SEQUENCE producto_pk_seq;
DROP SEQUENCE empresa_pk_seq;
DROP SEQUENCE paquete_pk_seq;
DROP SEQUENCE producto_orden_pk_seq;
DROP SEQUENCE streaming_pk_seq;
DROP SEQUENCE fisico_pk_seq;
DROP SEQUENCE videojuego_pk_seq;
DROP SEQUENCE album_musical_pk_seq;
DROP SEQUENCE pelicula_pk_seq;
DROP SEQUENCE escala_pk_seq;


