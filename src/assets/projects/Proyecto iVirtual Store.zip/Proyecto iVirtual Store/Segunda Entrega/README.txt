Lea con atencion las instrucciones

++++++++++++++++++++++++++++++++++

Usted debera ingresar a sql con el usuario postgre y dar todos los privilegios de la base creada a el usuario con el que ara las modificaciones.

Puede crear la base con los siguientes comandos:

CREATE DATABASE ivirtual;          ----------> Para crear la base con nombre ivirtual

CREATE USER usuario WITH PASSWORD  '1q2w3e4r'  ------------> Donde usuario es el nombre con el que se identificara y lo que esta dentro de las comillas la contraseña de ese usuario.

GRANT ALL PRIVILEGES ON DATABASE ivirtual TO usuario                -------> Donde usuario es el nombre de usuario con el que manejara la base

++++++++++++++++++++++++++++++++++

Una vez que se haya generado la base y se hayan dado los permisos al usuario que 
la va a manejar, tenemos que ejecutar los siguientes comandos desde la consola de linux.

cd ruta_completa               --------> Nos colocaremos en el directorio donde se encuentra este archivo 

\i CreacionBD.sql		--------> Creara las tablas de la base de datos
\i inserciones.sql		--------> Insertara algunos datos a estas tablas
\i Prueba_Datos.sql		--------> Probara inserciones invalidas, por lo cual es normal que solo marque errores
\i consult.sql			--------> Hara algunas consultas de las tablas uniendo partes de una en otra

++++++++++++++++++++++++++++++++++

Pruebe insertando mas datos a la base en diferentes tablas con la sintaxis empleada en el archivo inserciones.sql
