

-- 1.- INSERCION CON UN NOMBRE DE USUARIO IGUAL (Debajo se muestra el usuario que ya esta ingresado al ejecutar el script "inserciones.sql")

--INSERT INTO cliente (cliente_id, usuario, contraseña, RFC, telefono, nombre, ap_paterno, ap_materno)
	--values (nextval('cliente_pk_seq'), 'Juan67', '1q2w3e', 'AKDBYW7382937', '5558093480', 'Juan', 'Ramirez', 'Perez');

INSERT INTO cliente (cliente_id, usuario, contraseña, telefono, nombre, ap_paterno, ap_materno)
	values (nextval('cliente_pk_seq'), 'Juan67', 'Juanitocn', '0192778109', 'Juan', 'Alvarez', 'Rosas');

-- 2.- INSERSION DE UN TIPO DE PRODUTO NO VALIDO

INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'W', 'PPPPPPPPP1', 150, 0, 1);

-- 3.- INSERCION DE UN PRODUCTO QUE NO ES NI FISICO NI STREAM

INSERT INTO producto(producto_id, tipo, folio, precio_venta, es_streaming, es_fisico)
	values(nextval('producto_pk_seq'), 'P', 'PPPPPPPPP1', 150, 0, 0);

-- 4.- INSERCION DE UNA CLASIFICACION DE PELICULA NO VALIDA

INSERT INTO pelicula (producto_id, nombre, genero, duracion, clasificacion, formato_video)
	values(1, 'Sonic', 'Live Action', 121, 'Z', 'HD 1080p');

-- 5.- INSERCION EN UNA ORDEN DE COMPRA CON CERO PRODUCTOS

INSERT INTO producto_orden (producto_orden_id, precio_unitario, cantidad, producto_id, orden_id)
	values(nextval('producto_orden_pk_seq'), 150, 0, 1, 4);

-- 6.- INSERCION DE UN PAQUETE CON UN NUMERO DE SEGUIMIENTO QUE NO ES DE 24 CARACTERES

INSERT INTO paquete (paquete_id, numero_seguimiento, peso, fecha_envio, dimension, empresa_id, factura_id)
	values(nextval('paquete_pk_seq'), '9823 0983 0111 0192 938', 1.5, current_date, '50x30x10', 1, 4);

-- 7.- INSERCION DE UNA EMPRESA CON UNA ZONA DE COBERTURA INVALIDA

INSERT INTO empresa (empresa_id, nombre, clave, zona_cobertura)
	values(nextval('empresa_pk_seq'), 'DHL', 'DHL01', 'D');

-- 8.- INSERCION DE UNA ORDEN CON UN FOLIO DE LONGITUD MENOR A 10

INSERT INTO orden(orden_id, fecha_status, folio, cliente_id, status_compra_id)
	values(nextval('orden_pk_seq'), current_date, 'AAAA1', 3, 1);

-- 9.- INSERCION DE EN EL STATUS DE COMPRA CON UNA CLAVE INVALIDA

INSERT INTO status_compra (status_compra_id, clave, descripcion, activo)
	values(nextval('status_compra_pk_seq'), 'M', 'Orden generada', '1');

-- 10.- INSERCION DE UN TIPO DE PAGO INVALIDO

INSERT INTO tipo_forma_pago (tipo_forma_pago_id, clave, nombre, descripcion, tipo)
	values(nextval('tipo_forma_pago_pk_seq'), 'clave1', 'Tarjeta de Credito', 'Tarjeta VISA', 'Z');
