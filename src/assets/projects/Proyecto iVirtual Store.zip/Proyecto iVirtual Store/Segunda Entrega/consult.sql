SELECT PE.nombre as "Nombre",PR.precio_venta as "Precio"
FROM pelicula PE
JOIN producto PR
ON PR.producto_id = PE.producto_id;


SELECT PA.numero_seguimiento as "Numero de Seguimiento", E.nombre as "Nombre de la empresa",E.zona_cobertura as "Zona de cobertura"
FROM paquete PA
JOIN empresa E
ON PA.empresa_id = E.empresa_id;


SELECT PR.folio as "Folio de producto",PP.folio as "Folio de producto promocionado"
FROM producto PR
LEFT JOIN producto PP
ON PR.promocion_id = PP.producto_id;


SELECT CL.usuario as "Usuario",CL.telefono as "Telefono", CL.nombre as "Nombre", CD.direccion as "Direccion"
FROM cliente CL
RIGHT JOIN cliente_direccion CD
ON CL.cliente_id = CD.cliente_id;


SELECT CL.usuario as "Usuario",CL.telefono as "Telefono", CL.nombre as "Nombre", CD.direccion as "Direccion"
FROM cliente CL
RIGHT JOIN cliente_direccion CD
ON CL.cliente_id = CD.cliente_id;

SELECT PA.numero_seguimiento as "Numero de Seguimiento", E.nombre as "Empresa",F.folio as "Folio de factura",F.fecha_generacion as "Fecha"
FROM paquete PA
JOIN empresa E
ON PA.empresa_id = E.empresa_id 
JOIN factura F
ON PA.factura_id = F.factura_id;

SELECT O.orden_id as "Numero orden",CL.nombre as "Nombre", PO.producto_orden_id as "Producto orden"
FROM orden O
JOIN producto_orden PO
ON O.orden_id = PO.orden_id
JOIN cliente CL
ON O.cliente_id = CL.cliente_id; 

SELECT O.folio as "Folio de Orden", SC.descripcion as "Descripcion",SC.activo as "Activo"
FROM orden O
LEFT JOIN status_compra SC
ON O.status_compra_id = SC.status_compra_id;

SELECT F.folio as "Folio de factura", CFP.tipo_forma_pago_id as "Forma de pago identificador"
FROM factura F
JOIN cliente_forma_pago CFP
ON F.cliente_forma_pago_id = CFP.cliente_forma_pago_id;

SELECT *
FROM videojuego V
NATURAL JOIN producto PR;

SELECT PE.nombre as "pelicula"
FROM pelicula PE
WHERE (SELECT PR.precio_venta FROM producto PR
	  WHERE PR.producto_id = PE.producto_id) > (SELECT PR.precio_venta FROM producto PR
											   WHERE PR.producto_id = 4);

SELECT F.folio as "Folio de factura"
FROM factura F
WHERE F.total > (SELECT F.total FROM factura F WHERE F.folio = 2584561597);
	  
