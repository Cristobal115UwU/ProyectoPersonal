CREATE SEQUENCE cliente_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE orden_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE factura_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE empresa_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;



CREATE SEQUENCE producto_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE paquete_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE escala_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE tipo_forma_pago_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE cliente_forma_pago_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE cliente_direccion_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE producto_orden_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE status_compra_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE historico_status_compra_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;



--creando tablas---


CREATE TABLE cliente(
	cliente_id NUMERIC(10,0) DEFAULT nextval('cliente_pk_seq') NOT NULL,
	usuario VARCHAR(20) UNIQUE NOT NULL,
	contraseña VARCHAR(10) NOT NULL,
	RFC VARCHAR(13) NULL,
	telefono VARCHAR(20) NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	ap_paterno VARCHAR(40) NOT NULL,
	ap_materno VARCHAR(40) NULL,
	CONSTRAINT cliente_pk PRIMARY KEY (cliente_id),
	CONSTRAINT check_rfc CHECK (char_length(RFC) = 13)
);



CREATE TABLE cliente_direccion(
	direccion_id NUMERIC(10,0) DEFAULT nextval('cliente_direccion_pk_seq') NOT NULL,
	direccion VARCHAR(200) NOT NULL,
	cliente_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT direccion_pk PRIMARY KEY (direccion_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) REFERENCES cliente(cliente_id)
);




CREATE TABLE tipo_forma_pago(
	tipo_forma_pago_id NUMERIC(10,0) DEFAULT nextval('tipo_forma_pago_pk_seq') NOT NULL,
	clave VARCHAR(20) NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	descripcion VARCHAR(100) NOT NULL,
	tipo VARCHAR(1) NOT NULL,
	CONSTRAINT tipo_forma_pago_pk PRIMARY KEY (tipo_forma_pago_id),
	CONSTRAINT check_tipo CHECK (tipo='T' OR tipo = 'E' OR tipo = 'B')
);



CREATE TABLE cliente_forma_pago(
	cliente_forma_pago_id NUMERIC(10,0) DEFAULT nextval('cliente_forma_pago_pk_seq') NOT NULL,
	num_tarjeta VARCHAR(40) NULL,
	clabe VARCHAR(40) NULL,
	fecha_expriracion DATE NULL, --Creo que faltaria revisar el formato de la fecha
	cliente_id NUMERIC(10,0) NOT NULL,
	tipo_forma_pago_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT cliente_forma_pago_pk PRIMARY KEY (cliente_forma_pago_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) REFERENCES cliente(cliente_id),
	CONSTRAINT tipo_forma_pago_fk FOREIGN KEY (tipo_forma_pago_id) REFERENCES tipo_forma_pago(tipo_forma_pago_id)
);



CREATE TABLE status_compra(
	status_compra_id NUMERIC(2,0) DEFAULT nextval('status_compra_pk_seq') NOT NULL,
	clave VARCHAR(1) NOT NULL,
	descripcion VARCHAR(100) NOT NULL,
	activo VARCHAR(1) NOT NULL,
	CONSTRAINT status_compra_pk PRIMARY KEY (status_compra_id),
	CONSTRAINT check_clave CHECK (clave = 'R' OR clave = 'P' OR clave = 'V' OR clave = 'C' OR clave = 'S'
		OR clave = 'E' OR clave = 'D')
);




CREATE TABLE orden(
	orden_id NUMERIC(10,0) DEFAULT nextval('orden_pk_seq') NOT NULL,
	fecha_status DATE NOT NULL,
	folio VARCHAR(10) NOT NULL,
	cliente_id NUMERIC(10,0) NOT NULL,
	status_compra_id NUMERIC(2,0) NOT NULL,
	CONSTRAINT orden_pk PRIMARY KEY (orden_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) REFERENCES cliente(cliente_id),
	CONSTRAINT status_compra_fk FOREIGN KEY (status_compra_id) REFERENCES status_compra(status_compra_id),
	CONSTRAINT check_folio CHECK (char_length(folio) = 10)
);




CREATE TABLE historico_status_compra(
	historico_status_compra_id NUMERIC(10,0) DEFAULT nextval('historico_status_compra_pk_seq') NOT NULL,
	fecha_status DATE NOT NULL,
	status_compra_id NUMERIC(2,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT historico_status_compra_pk PRIMARY KEY (historico_status_compra_id),
	CONSTRAINT status_compra_fk FOREIGN KEY (status_compra_id) REFERENCES status_compra(status_compra_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) REFERENCES orden(orden_id)
);




CREATE TABLE factura(
	factura_id NUMERIC(10,0) DEFAULT nextval('factura_pk_seq') NOT NULL,
	fecha_generacion DATE NOT NULL,
	total NUMERIC(18,2) NOT NULL,
	iva NUMERIC(18,2) NOT NULL,
	folio NUMERIC(10,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	cliente_forma_pago_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT factura_pk PRIMARY KEY (factura_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) REFERENCES orden(orden_id),
	CONSTRAINT cliente_forma_pago_fk FOREIGN KEY (cliente_forma_pago_id) REFERENCES cliente_forma_pago(cliente_forma_pago_id)	
);



CREATE TABLE producto(
    producto_id NUMERIC(10,0) DEFAULT nextval('producto_pk_seq') NOT NULL,
    tipo         VARCHAR(1)      NOT NULL,
    folio        VARCHAR(13)     NOT NULL,
    precio_venta NUMERIC(8,2)    NOT NULL,
    es_streaming NUMERIC(1,0)    NOT NULL,
    es_fisico    NUMERIC(1,0)    NOT NULL,
    promocion_id NUMERIC(10,0)   NULL,
    CONSTRAINT producto_pk PRIMARY KEY (producto_id),
    CONSTRAINT promocion_fk FOREIGN KEY (promocion_id) REFERENCES producto(producto_id),
	CONSTRAINT check_tipo CHECK (tipo = 'V' OR tipo = 'P' OR tipo = 'A'),
	--CONSTRAINT check_streaming CHECK (es_streaming = 0 OR es_streaming = 1),
	--CONSTRAINT check_fisico CHECK (es_fisico = 0 OR es_fisico = 1)
	CONSTRAINT check_fisico_stream CHECK ((es_fisico = 0 AND es_streaming = 1) OR (es_fisico = 1 AND es_streaming = 0) OR (es_fisico = 1 AND es_streaming = 1))
);



CREATE TABLE empresa(
	empresa_id NUMERIC(10,0) DEFAULT nextval('empresa_pk_seq') NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	clave VARCHAR(10) UNIQUE NOT NULL,
	zona_cobertura VARCHAR(1) NOT NULL, --Cambie una letra, no creo que se rompa, pero decia soba
	CONSTRAINT empresa_pk PRIMARY KEY (empresa_id),
	CONSTRAINT check_cobertura CHECK (zona_cobertura = 'A' OR zona_cobertura = 'B' OR zona_cobertura = 'C')
);




CREATE TABLE paquete(
	paquete_id NUMERIC(10,0) DEFAULT nextval('paquete_pk_seq') NOT NULL,
	numero_seguimiento VARCHAR(24) NOT NULL,
	peso NUMERIC(8,4) NOT NULL,
	fecha_envio DATE NOT NULL,
	dimension VARCHAR(17) NOT NULL,
	empresa_id NUMERIC(10,0) NOT NULL,
	factura_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT paquete_pk PRIMARY KEY(paquete_id),
	CONSTRAINT empresa_fk FOREIGN KEY (empresa_id) REFERENCES empresa(empresa_id),
	CONSTRAINT factura_fk FOREIGN KEY (factura_id) REFERENCES factura(factura_id),
	CONSTRAINT check_num_seguimiento CHECK (char_length(numero_seguimiento) = 24)
);



CREATE TABLE producto_orden(
	producto_orden_id NUMERIC(10,0) DEFAULT nextval('producto_orden_pk_seq') NOT NULL,
	precio_unitario NUMERIC(10,2) NOT NULL,
	cantidad NUMERIC(10,0) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT producto_orden_pk PRIMARY KEY (producto_orden_id),
	CONSTRAINT producto_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) REFERENCES orden(orden_id),
	CONSTRAINT check_cantidad CHECK (cantidad > 0)
);


CREATE TABLE streaming(
	producto_id NUMERIC(10,0) NOT NULL,
	URL VARCHAR(40)  NOT NULL,
	reproducciones NUMERIC(18,0) NOT NULL,
	CONSTRAINT streaming_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT streaming_pk PRIMARY KEY (producto_id)
);



CREATE TABLE fisico(
	producto_id NUMERIC(10,0) NOT NULL,
	copias_vendidas NUMERIC(10,0) NOT NULL,
	copias_existencia NUMERIC(10,0) NOT NULL,
	copias_defectuosas NUMERIC(10,0) NOT NULL,
	CONSTRAINT fisico_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT fisico_pk PRIMARY KEY (producto_id)
);


CREATE TABLE videojuego(
	producto_id NUMERIC(10,0) NOT NULL,
	nombre VARCHAR(40)  NOT NULL,
	descripcion VARCHAR(40) NOT NULL,
	tipo_consola VARCHAR(40) NOT NULL,
	CONSTRAINT videojuego_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT videojuego_pk PRIMARY KEY (producto_id)
	
);



CREATE TABLE album_musical( 
	producto_id NUMERIC(10,0) NOT NULL,
	autor VARCHAR(40)  NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	año_creacion NUMERIC(4,0) NOT NULL,
	disquera VARCHAR(40) NOT NULL,
	CONSTRAINT album_musical_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT album_pk PRIMARY KEY (producto_id)
);




CREATE TABLE pelicula(
	producto_id NUMERIC(10,0) NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	genero VARCHAR(40) NOT NULL,
	duracion numeric(4,0) NOT NULL,
	clasificacion VARCHAR(1) CHECK (clasificacion='A' OR clasificacion = 'B' OR clasificacion = 'C') NOT NULL,
	formato_video VARCHAR(40) NOT NULL,
	CONSTRAINT pelicula_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT pelicula_pk PRIMARY KEY (producto_id),
	CONSTRAINT check_clasificacion CHECK (clasificacion ='A' OR clasificacion = 'B' OR clasificacion = 'C')
);


CREATE TABLE escala(
	paquete_id NUMERIC(10,0) NOT NULL,
	numero_escala NUMERIC(4,0) DEFAULT nextval('escala_pk_seq'),
	lugar VARCHAR(100) NOT NULL,
	fecha_hora_arrivo DATE NOT NULL,
	CONSTRAINT paquete_fk FOREIGN KEY (paquete_id) REFERENCES paquete(paquete_id),
  	CONSTRAINT escala_pk PRIMARY KEY (numero_escala, paquete_id)
);
