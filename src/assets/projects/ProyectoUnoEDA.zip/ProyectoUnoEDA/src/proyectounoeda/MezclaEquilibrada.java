/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectounoeda;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 *Contiene los métodos para ordenar las claves mediante el metodo mezcla equilibrada
 * @author Equipo4EdaII
 */
public class MezclaEquilibrada{
    /**
     * Metodo para Escribir en archivo
     * @param num Elemento a escribir en el archivo 
     * @param nombre Nombre del archivo donde se va escribir
     * @param endL Indica que es el ultimo elemento a insertar en el bloque especifico
     */
    public static void writeInFile(Double num, String nombre, boolean endL) {
        FileWriter flwriter = null;
        try {
            flwriter = new FileWriter(".\\files\\mezclaEqui\\"+nombre+".txt",true);
            BufferedWriter bfwriter = new BufferedWriter(flwriter); //Apertura arhivo con claves
            if(endL == false)
                bfwriter.write(num+","); //Escribe el numero con una coma para que mas elementos del bloque sean escritos
            else
                bfwriter.append(num+"\n");//Al ser el ultimo elemento del bloque se inserta un salto de linea
            bfwriter.close();
        } catch (IOException e) {
                System.out.println("Unable to write");
        } finally {
            if (flwriter != null) {
                try {
                        flwriter.close();//Cierra el archivo
                } catch (IOException e) {
                        System.out.println("Unable to close");
                }
            }
        }
    }
    /**
     * Lectura y separación por bloques ascendentes de las claves
     * @param nombreAr Nombre del Archivo
     * @return Si fue posible o no leer el contenido del archivo uno y hacer la separación 
     */
    public static boolean leerArchivoPrincipalAsc(String nombreAr) {
        File file = new File(".\\files\\claves\\"+nombreAr+".txt");
        if(!file.exists()){
                System.out.println("\tNo se encontró el archivo");
                return false;
        }
        try {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();//Lee el contenido del archivo
                Scanner delimitar = new Scanner(linea);			
                delimitar.useDelimiter("\\s*,\\s*");
                Scanner del = new Scanner(linea);			
                del.useDelimiter("\\s*,\\s*");//Delimitaciones por comas

                String obj ; //La variable objeto es el objeto a evaluar
                String aux;  //Segunda variable auxiliar para comparar quien es el mayor
                String numArchivo = "arch1"; //Variable para ver en que archivo auxiliar se va a insertar
                int contador = MezclaEquilibrada.countComma(del); 
                obj = delimitar.next();
                aux = delimitar.next();
                for(int i=0; i< contador -2 ;i++){ //For para iterar el numero exacto de elementos que tiene menos los que se sacaroon previamente
                    if(Double.parseDouble(obj) <= Double.parseDouble(aux)){ //Comparación para formar los bloques
                        MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,false);
                        if(delimitar.hasNext()){//Adignari siguintes elementos si existen
                            obj = aux;
                            aux = delimitar.next();
                        }
                    }else{
                        MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,true); //El elemento es el ultimo del bloque, se escribe
                        numArchivo = MezclaEquilibrada.numFile(numArchivo);//Cambio del archivo auxiliar a usar
                        if(delimitar.hasNext()){
                            obj = aux;
                            aux = delimitar.next();
                        }
                    }
                }
                //Los ultimos dos elementos quedan flotando y evaluamos los dos posibles casos
                if(Double.parseDouble(obj) <= Double.parseDouble(aux)){//Si pertenecen al mismo bloque se escriben
                    MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,false);
                    MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,true);//Ultimo del bloque
                }else{
                    MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,true);//No pertenecen al mismo bloque y se ingresan en bloques diferentes
                    numArchivo = MezclaEquilibrada.numFile(numArchivo);
                    MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,true);
                }
            }        
            sc.close();
            
        }catch (FileNotFoundException e) {
            System.out.println("Scanner unable to use");
        }
        return true;
    }
    /**
     * Lectura y separación por bloques descendente de las claves
     * @param nombreAr Nombre Archivo a leer;
     * @return Si fue posible o no leer el contenido del archivo uno y hacer la separación 
     */
    
     public static boolean leerArchivoPrincipalDes(String nombreAr) {
        File file = new File(".\\files\\claves\\"+nombreAr+".txt");
        if(!file.exists()){
                System.out.println("\tNo se encontró el archivo");
                return false;
        }
        try {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                Scanner delimitar = new Scanner(linea);			
                delimitar.useDelimiter("\\s*,\\s*");
                Scanner del = new Scanner(linea);			
                del.useDelimiter("\\s*,\\s*");

                String obj ; //La variable objeto es el objeto a evaluar
                String aux;
                String numArchivo = "arch1";
                int contador = MezclaEquilibrada.countComma(del);
                obj = delimitar.next();
                aux = delimitar.next();
                for(int i=0; i< contador -2 ;i++){ 
                    if(Double.parseDouble(obj) >= Double.parseDouble(aux)){
                        MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,false);
                        if(delimitar.hasNext()){
                            obj = aux;
                            aux = delimitar.next();
                        }
                    }else{
                        MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,true);
                        numArchivo = MezclaEquilibrada.numFile(numArchivo);
                        if(delimitar.hasNext()){
                            obj = aux;
                            aux = delimitar.next();
                        }
                    }
                }
                if(Double.parseDouble(obj) >= Double.parseDouble(aux)){
                    MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,false);
                    MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,true);
                }else{
                    MezclaEquilibrada.writeInFile(Double.parseDouble(obj), numArchivo,true);
                    numArchivo = MezclaEquilibrada.numFile(numArchivo);
                    MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,true);
                }
            }        
            sc.close();
            
        }catch (FileNotFoundException e) {
                e.printStackTrace();       
        }
        return true;
    }
    /**
     * Separacion de bloques del archivo principal en archivos auxiliares
     * @param nombreAr Nombre del archivo donde se separan bloques
     * @return 
     */ 
    public static boolean mezclarBloques(String nombreAr){
        File file = new File(".\\files\\mezclaEqui\\"+nombreAr+".txt");
        try{
            Scanner mainFile = new Scanner(file);
            String numArchivo = "arch1";

            while(mainFile.hasNextLine()){//Iteracion  mientras haya bloques en el archivo
                String linea = mainFile.nextLine();
                Scanner delimitar = new Scanner(linea);			
                delimitar.useDelimiter("\\s*,\\s*");//Delimitacion
                String aux;
                while(delimitar.hasNext()){//Mientras cada linea (bloque) contenga elementos se escriben en el archivo auxiliar indicado
                    aux = delimitar.next();
                    if(!delimitar.hasNext()){//Si no tiene mas elementos es el ultimo y se cambia de archivo auxiliar
                        MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,true);
                        numArchivo=MezclaEquilibrada.numFile(numArchivo);
                    }
                    else
                        MezclaEquilibrada.writeInFile(Double.parseDouble(aux), numArchivo,false); 
                }   
            }
        }catch(FileNotFoundException e){
            System.out.println("Unable to merge stacks");
        }
        return true;
    }
    /**
     * Metodo para fusionar los bloques e ingresarlos en el principal de manera ascendente
     * @param nombreAr Nombre Archivo Principal
     * @return Si se logró juntar los archivos
     */
    public static boolean juntarArchviosAsc(String nombreAr){
        File auxFile1 = new File(".\\files\\mezclaEqui\\arch1.txt");    //Apertura de archivos auxiliares
        File auxFile2 = new File(".\\files\\mezclaEqui\\arch2.txt");
        
        Queue <Double> q1 = new LinkedList<>();
        Queue <Double> q2 = new LinkedList<>();
        try {
                    //se pasa el flujo al objeto scanner
            Scanner scAux1 = new Scanner(auxFile1);
            Scanner scAux2 = new Scanner(auxFile2);//Tomar contenido de archivos

            while (scAux1.hasNextLine() && scAux2.hasNextLine()) {//Mientras ambos archivos tengan un bloque que se vaya a combinar
                String lineaAux1 = scAux1.nextLine();//Lecura de bloques correspondientes al archivo auxiliar indicado
                String lineaAux2 = scAux2.nextLine();


                Scanner delimitarAux1 = new Scanner(lineaAux1);			
                Scanner delimitarAux2 = new Scanner(lineaAux2);			

                delimitarAux1.useDelimiter("\\s*,\\s*");//Delimitación
                delimitarAux2.useDelimiter("\\s*,\\s*");
             
                //lenar cola 1 con elementos del archivo auxiliar 1  
                while(delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));
                }
                //lenar cola 12 con elementos del archivo auxiliar 2
                while(delimitarAux2.hasNext()){
                    q2.add(Double.parseDouble(delimitarAux2.next()));
                }
                //Cuando ambas colas tengan elementos se comparan para indicar cual va primero
                while(!q1.isEmpty() && !q2.isEmpty()){
                    if(q1.peek()< q2.peek()){
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);
                    }else{
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, false);
                    }
                }    
                //Cuando la cola uno aun tenga elementos y la segunda no ingresará los elementos restantes
                while(!q1.isEmpty() && q2.isEmpty()){
                    if(q1.size() == 1){//Cuando quede un elemento se usara un salto de linea para indicar que se termino de combinar los bloques
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);

                }
                //Cuando la cola dos aun tenga elementos y la primera no, ingresará los elementos restantes
                while(q1.isEmpty() && !q2.isEmpty()){
                    if(q2.size() == 1){//Cuando quede un elemento se usara un salto de linea para indicar que se termino de combinar los bloques
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, false);

                }
            }
            //Cuando solo haya un bloque en el archivo auxiliar 1 se ingresaran todos en el orden dado
            while (scAux1.hasNextLine() && !scAux2.hasNextLine()) {
                String lineaAux1 = scAux1.nextLine();
                Scanner delimitarAux1 = new Scanner(lineaAux1);
                delimitarAux1.useDelimiter("\\s*,\\s*");
                while(delimitarAux1.hasNext()) { //Meter elementos a la cola
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while(!q1.isEmpty()){ //Mientras tenga elementos los ingresara al archivo indicado
                    if(q1.size() == 1){//Cuando sea el ultimo se le agrega un salto de linea
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);
                }
                
            }
            
            scAux1.close();
            scAux2.close();
        } catch (FileNotFoundException e) {
                e.printStackTrace();
        }
        
        
        return false;
    }
    /**
     * Metodo para fusionar los bloques e ingresarlos en el principal de manera descendente
     * @param nombreAr Nombre Archivo Principal
     * @return Si se logró juntar los archivos
     */
    public static boolean juntarArchviosDes(String nombreAr){
        File auxFile1 = new File(".\\files\\mezclaEqui\\arch1.txt");
        File auxFile2 = new File(".\\files\\mezclaEqui\\arch2.txt");
        
        Queue <Double> q1 = new LinkedList<>();
        Queue <Double> q2 = new LinkedList<>();
        try {
                    //se pasa el flujo al objeto scanner
            Scanner scAux1 = new Scanner(auxFile1);
            Scanner scAux2 = new Scanner(auxFile2);

            while (scAux1.hasNextLine() && scAux2.hasNextLine()) {
                String lineaAux1 = scAux1.nextLine();
                String lineaAux2 = scAux2.nextLine();


                Scanner delimitarAux1 = new Scanner(lineaAux1);			
                Scanner delimitarAux2 = new Scanner(lineaAux2);			

                delimitarAux1.useDelimiter("\\s*,\\s*");
                delimitarAux2.useDelimiter("\\s*,\\s*");
                
                //double cola1;
                //double cola2;

                while(delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while(delimitarAux2.hasNext()){
                    q2.add(Double.parseDouble(delimitarAux2.next()));

                }
                while(!q1.isEmpty() && !q2.isEmpty()){
                    if(q1.peek() > q2.peek()){
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);
                    }else{
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, false);
                    }
                }    

                while(!q1.isEmpty() && q2.isEmpty()){
                    if(q1.size() == 1){
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);

                }
                while(q1.isEmpty() && !q2.isEmpty()){
                    if(q2.size() == 1){
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q2.remove(), nombreAr, false);

                }
            }
            while (scAux1.hasNextLine() && !scAux2.hasNextLine()) {
                String lineaAux1 = scAux1.nextLine();
                Scanner delimitarAux1 = new Scanner(lineaAux1);
                delimitarAux1.useDelimiter("\\s*,\\s*");
                while(delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while(!q1.isEmpty()){
                    if(q1.size() == 1){
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, true);
                    }
                    else
                        MezclaEquilibrada.writeInFile(q1.remove(), nombreAr, false);

                }
                
            }
            scAux1.close();
            scAux2.close();
        } catch (FileNotFoundException e) {
                e.printStackTrace();
        }
        
        
        return false;
    }
    /**
     * Borrara el contenido de los archivos auxiliares
     * @return si fue exitosa borrar el contenido de los archivos
     */
    public static boolean borrarContAux(){
        
        try{
            FileWriter auxFile1 = new FileWriter(".\\files\\mezclaEqui\\arch1.txt",false);//Apertira de archivos, el false insica que no se va a sobre escribir
            FileWriter auxFile2 = new FileWriter(".\\files\\mezclaEqui\\arch2.txt",false);
        }catch(IOException e){
            System.out.println("Hubo un error");
        }
        return true;
    }
    /**
     * Borrar el contenido del archivo principal
     * @param nombreAr Nombre del Archivo Principal
     * @return 
     */
    public static boolean borrarPrincipal(String nombreAr){
        try{
            FileWriter auxFile1 = new FileWriter(".\\files\\mezclaEqui\\"+nombreAr+".txt",false); //Apertira de archivo, el false insica que no se va a sobre escribir  
        }catch(IOException e){
            System.out.println("No se encontró el arrchivo principal a borrar");
        }
        return true;
    }
    /**
     * Metodo de verificación si las claves ya estan ordenadas
     * @return Si el erchivo esta ordenado
     */
    public static boolean isOrdenado(){ 
        File auxFile2 = new File(".\\files\\mezclaEqui\\arch2.txt");
        try{
            Scanner scAux2 = new Scanner(auxFile2);
            if(scAux2.hasNextLine())//Si existe algun elemento en el archivo 2 aun no esta ordenado
                return false;
            else
                return true; 
        }catch(FileNotFoundException e){
            System.out.println("No se encoontró el archivo auxiliar");
        }
       
        return true;
    }
    /**
     * Contador de comas para saber cuantos elementos tiene le bloque 
     * @param delimitar Scanner con los elementos demimitados por comas
     * @return 
     */
    public static int countComma(Scanner delimitar){
        int contador =0;
        while(delimitar.hasNext()){
            contador++;
            delimitar.next();
        }
        return contador;
    }
    /**
     * Metodo para cambiar de archivo auxiliar a usar
     * @param numArchivo Nombre de Archivo Acutal
     * @return Nombre de Archivo Actualizado
     */
    public static String numFile(String numArchivo){
        if(numArchivo.equals("arch1"))
            numArchivo= "arch2";
        else
            numArchivo="arch1";
        return numArchivo;
    }
    /**
     * Metodo para crear el archivo prinicpal
     * @param nombre 
     */
    public static void createFile(String nombre){
        try {
            String ruta = ".\\files\\mezclaEqui\\"+nombre+".txt";
            File file = new File(ruta);
            
            if (!file.exists()) {
                file.createNewFile();
            }else{
                borrarPrincipal(nombre);
            }
            
        } catch (Exception e) {
           
        }
    }
    /**
     * Metodo para imprimir el contenido de los archivos
     * @param nombre 
     */
    public static void imprmirDatosArchvio(String nombre){
        try {
            File arch = new File(".\\files\\mezclaEqui\\"+nombre+".txt");
            Scanner contenido = new Scanner(arch); //Apertura de archivo
            System.out.println("\tCONTENIDO "+nombre.toUpperCase());
            String imprimir;
            while(contenido.hasNext()){//Impresion de cada bloque (renglon)
                imprimir = contenido.next();
                System.out.println("\t\t["+imprimir+"]");
            }
        } catch (FileNotFoundException ex) {
            System.out.println("NOP");
        }
    }
}
