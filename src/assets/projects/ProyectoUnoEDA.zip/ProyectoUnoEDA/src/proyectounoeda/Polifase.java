/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectounoeda;

import java.util.*;
import java.io.*;
/**
 * Contiene los métodos para ordenar las claves mediante el metodo mezcla equilibrada
 * @author Equipo4EdaII
 */
public class Polifase {
    /**
     * Metodo para Escribir en archivo
     * @param lista Elemento a escribir en el archivo 
     * @param nombre Nombre del archivo donde se va escribir
     * @param endL Indica que es el ultimo elemento a insertar en el bloque especifico
     */
    public static void writeInFile(Double lista, String nombre, boolean endL) {
        FileWriter flwriter = null;
        try {
            //crea el flujo para escribir en el archivo
            flwriter = new FileWriter(".\\files\\polifase\\" + nombre + ".txt", true);
            //crea un buffer o flujo intermedio antes de escribir directamente en el archivo
            BufferedWriter bfwriter = new BufferedWriter(flwriter);
            if (endL == false) {
                bfwriter.write(lista + ",");
            } else {
                bfwriter.append(lista + "\n");
            }

            //cierra el buffer intermedio
            bfwriter.close();
           

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (flwriter != null) {
                try {//cierra el flujo principal
                    flwriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * 
     * @param nombreAr Nombre del archivo Original con las claves
     * @param numero Es el numero de claves por bloque 
     * @return si fue posible leer el archivo
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public static boolean leerArchivoPrincipalAsc(String nombreAr,int numero) throws FileNotFoundException, IOException {
        ArrayList <Double>Lista = new ArrayList<>();
        File file = new File(".\\files\\claves\\" + nombreAr + ".txt");
        if (!file.exists()) {
            System.out.println("\tNo existe el archivo existente");
            return false;    
        }
        String fileAu1 = "arch1";
        String fileAu2 = "arch2";
        boolean arch;
        Scanner bw = new Scanner(file);
        while (bw.hasNextLine()) { //Mientras no haya un salto de linea, seguimos leyendo la linea
            String linea = bw.nextLine();
            Scanner delimitar = new Scanner(linea);//Creamos un objeto Scanner que reciba la linea de las claves para poder iterar sobre esa linea 
            delimitar.useDelimiter("\\s*,\\s*");
            String obj; //La variable objeto sera el elemento a evaluar
            while (delimitar.hasNext()) {//Mientras la linea tenga elementos, insertaremos los elementos por bloque en los archivos auxiliares
                for (int i=0;i<numero;i++){
                    if(delimitar.hasNext()){//Si el elemento que estamos analizando tiene otro elemento, entonces no es el ultimo elemento
                        obj = delimitar.next(); 
                        Lista.add(Double.parseDouble(obj)); 
                    }
                    else
                        break;
                }
                Double []arr1 = new Double[Lista.size()]; 
                arr1 = Lista.toArray(arr1);//Convertimos de arreglo dinamico a estatico
                Lista.clear();
                sort(arr1,0,arr1.length-1);//Ordenacion ascendente usando QuickSort
                arch=false;//Bandera
                for (int i=0;i<numero;i++){
                    if(i==numero-1){
                        arch=true;//Cuando sea el ultimo elemento del bloque, cambiamos la bandera para indicar que hay un salto de linea
                    }
                    if(delimitar.hasNext()){ 
                        Polifase.writeInFile(arr1[i], fileAu1, arch); //Agrega el elemento al archivo auxiliar 1
                    }
                    else{
                        InsertarSobrantes(arr1,fileAu1);//Si hay elementos que no completaron el bloque, entonces los agregamos por aparte
                        break;
                    }
                }    
                for (int j=0;j<numero;j++){//Todo la metodologia pero en el archivo auxiliar 2
                    if(delimitar.hasNext()){
                        obj = delimitar.next();   
                        Lista.add(Double.parseDouble(obj)); 
                    }
                    else
                        break;
                }
                Double []arr2 = new Double[Lista.size()];
                arr2 = Lista.toArray(arr2);
                Lista.clear();
                sort(arr2,0,arr2.length-1);
                arch=false;
                for (int i=0;i<numero;i++){
                    if(i==numero-1){
                        arch=true;
                    }
                    if(delimitar.hasNext()){ 
                        Polifase.writeInFile(arr2[i], fileAu2, arch);  
                    }
                    else{
                       InsertarSobrantes(arr2,fileAu2);
                       break;
                    }    
                }    
            }      
        }
        return true;//Si se pudo leer y pasar los bloques a los archivos auxiliares entonces regresa true
    }
    /**
     * Metodo que lee y pasa los bloques del archivo original a los auxiliares pero de manera descendente
     * Es igual que leerArchivoPrincipalAsc
     * @param nombreAr Nombre archivo originañ
     * @param numero Cantidad de claves por bloque
     * @return true si se leyo todo el archivo original
     * @throws FileNotFoundException 
     */
    public static boolean leerArchivoPrincipalDes(String nombreAr,int numero) throws FileNotFoundException {
        ArrayList <Double>Lista = new ArrayList<>();
        File file = new File(".\\files\\claves\\" + nombreAr + ".txt");
        if (!file.exists()) {
            System.out.println("\tNo existe el archivo especificado");
            return false;    
        }
        String fileAu1 = "arch1";
        String fileAu2 = "arch2";
        boolean arch;
        Scanner bw = new Scanner(file);
        while (bw.hasNextLine()) {
            String linea = bw.nextLine();
            Scanner delimitar = new Scanner(linea);
            delimitar.useDelimiter("\\s*,\\s*");
            Scanner del = new Scanner(linea);
            del.useDelimiter("\\s*,\\s*");
            String obj; //La variable objeto es el objeto a evaluar
            while (delimitar.hasNext()) {
                for (int i=0;i<numero;i++){
                    if(delimitar.hasNext()){
                        obj = delimitar.next(); 
                        Lista.add(Double.parseDouble(obj));     
                    }
                    else
                        break;
                }
                Double []arr1 = new Double[Lista.size()];
                arr1 = Lista.toArray(arr1);
                Lista.clear();
                sortI(arr1,0,arr1.length-1);//Lo unico que cambia en este metodo es que usamos QuickSort para ordenar de manera descendente
                arch=false;
                for (int i=0;i<numero;i++){
                    if(i==numero-1){
                        arch=true;
                    }
                    if(delimitar.hasNext()){ 
                        Polifase.writeInFile(arr1[i], fileAu1, arch);  
                    }
                    else{
                        InsertarSobrantes(arr1,fileAu1);
                        break;
                    }
                }    
                for (int j=0;j<numero;j++){
                    if(delimitar.hasNext()){
                        obj = delimitar.next();   
                        Lista.add(Double.parseDouble(obj)); 
                    }
                    else
                        break;
                }
                Double []arr2 = new Double[Lista.size()];
                arr2 = Lista.toArray(arr2);
                Lista.clear();
                sortI(arr2,0,arr2.length-1);//QuickSort Descendente
                arch=false;
                for (int i=0;i<numero;i++){
                    if(i==numero-1){
                        arch=true;
                    }
                    if(delimitar.hasNext()){ 
                        Polifase.writeInFile(arr2[i], fileAu2, arch);  
                    }
                    else{
                       InsertarSobrantes(arr2,fileAu2);
                       break;
                    }    
                }    
            }      
        }
        return true;
    }
    /**
     * Metodo que tiene como tarea realizar la insercion de bloques del archivo final a los archivos principales
     * @param nombreAr Nombre del archivo final
     * @return true si se leyo todo el archivo
     * @throws IOException 
     */
    public static boolean mezclarBloquesAsc(String nombreAr) throws IOException {
        File file = new File(".\\files\\polifase\\" + nombreAr + ".txt");
        if(!file.exists())
            file.createNewFile();
        try {
            Scanner mainFile = new Scanner(file);
            String numArchivo = "arch1"; //Este String servira como bandera para intercalar los bloques entre archivo auxiliar 1 y 2

            while (mainFile.hasNextLine()) {//Mientras el archivo tenga bloques, los insertara en los archivos auxiliares
                String linea = mainFile.nextLine();
                Scanner delimitar = new Scanner(linea);
                delimitar.useDelimiter("\\s*,\\s*");
                String aux;
                while (delimitar.hasNext()) {//Mientras el bloque tenga claves, los mandara a los archivos auxiliares
                    aux = delimitar.next();
                    if (!delimitar.hasNext()) {
                        Polifase.writeInFile(Double.parseDouble(aux), numArchivo, true);
                        numArchivo = Polifase.numFile(numArchivo);//Cambiamos bandera a archivo auxiliar 2
                    } else {
                        Polifase.writeInFile(Double.parseDouble(aux), numArchivo, false);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return true;
    }
    /**
     * Metodo que inserta los elementos de los archivos auxiliares al archivo final
     * @param nombreAr Nombre del archivo final
     * @return true si se leyo exitosamente los archivos auxiliares
     */
    public static boolean juntarArchviosAsc(String nombreAr) {
        File auxFile1 = new File(".\\files\\polifase\\arch1.txt");
        File auxFile2 = new File(".\\files\\polifase\\arch2.txt");

        Queue<Double> q1 = new LinkedList<>();
        Queue<Double> q2 = new LinkedList<>();
        try {
            //se pasa el flujo al objeto scanner
            Scanner scAux1 = new Scanner(auxFile1);
            Scanner scAux2 = new Scanner(auxFile2);

            while (scAux1.hasNextLine() && scAux2.hasNextLine()) {//Mientras los archivos tengan bloques
                String lineaAux1 = scAux1.nextLine();
                String lineaAux2 = scAux2.nextLine();

                Scanner delimitarAux1 = new Scanner(lineaAux1);
                Scanner delimitarAux2 = new Scanner(lineaAux2);

                delimitarAux1.useDelimiter("\\s*,\\s*");
                delimitarAux2.useDelimiter("\\s*,\\s*");
                while (delimitarAux1.hasNext()) {//Mientras el bloque del archivo 1 tenga claves
                    q1.add(Double.parseDouble(delimitarAux1.next()));
                }
                while (delimitarAux2.hasNext()) {//Mientras el bloques del archivo 2 tenga claves
                    q2.add(Double.parseDouble(delimitarAux2.next()));

                }
                while (!q1.isEmpty() && !q2.isEmpty()) {
                    if (q1.peek() < q2.peek()) {//Comparamos elemento por elemento el contenido de las colas para insertarlas en el archivo final ya ordenadas
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    } else {
                        Polifase.writeInFile(q2.remove(), nombreAr, false);
                    }
                }

                while (!q1.isEmpty() && q2.isEmpty()) {//Insertara los elementos que no completaron el ultimo bloque
                    if (q1.size() == 1) {//Cuando este insertando el ultimo elemento del bloque, mandamos el salto de linea en el archivo final
                        Polifase.writeInFile(q1.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    }

                }
                while (q1.isEmpty() && !q2.isEmpty()) {
                    if (q2.size() == 1) {//De igual manera mandamos el salto de linea cuando quede un elemento
                        Polifase.writeInFile(q2.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q2.remove(), nombreAr, false);
                    }

                }
            }
            while (scAux1.hasNextLine() && !scAux2.hasNextLine()) {//Si en el archivo original quedaron bloques incompletos, las colas los añadiran
                String lineaAux1 = scAux1.nextLine();
                Scanner delimitarAux1 = new Scanner(lineaAux1);
                delimitarAux1.useDelimiter("\\s*,\\s*");
                while (delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while (!q1.isEmpty()) {
                    if (q1.size() == 1) {//Salto de linea si es el ultimo elemento
                        Polifase.writeInFile(q1.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    }

                }

            }

            scAux1.close();
            scAux2.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    }
    /**
     * Metodo que hace que los archivos auxiliares sean sobreescritos cuando queramos ingresar nuevos elementos en ellos
     * @return true si existen tales archivos
     */
    public static boolean borrarContAux() {

        try {
            FileWriter auxFile1 = new FileWriter(".\\files\\polifase\\arch1.txt", false);//El false indica que los archivos deberan ser sobreescritos
            FileWriter auxFile2 = new FileWriter(".\\files\\polifase\\arch2.txt", false);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
    /**
     * Metodo que hace que el archivo principal sea sobreescrito cuando queramos ingresar nuevos bloques de claves
     * @param nombreAr Nombre del archivo
     * @return true si existe el archivo
     */
    public static boolean borrarPrincipal(String nombreAr) {
        try {
            FileWriter auxFile1 = new FileWriter(".\\files\\polifase\\" + nombreAr + ".txt", false);//El false indica que los archivos deberan ser sobreescritos
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
    /**
     * Metodo que verifica que nuestro archivo principal ya esta ordenado
     * @return true si esta ordenado
     */
    public static boolean isOrdenado() {
        File auxFile2 = new File(".\\files\\polifase\\arch2.txt");
        try {
            Scanner scAux2 = new Scanner(auxFile2);
            if (scAux2.hasNextLine()) {//Cuando se termina el ordenamiento, el unico bloque que se inserta estara en archivo auxiliar 1
                return false;
            } else {
                return true;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return true;
    }
    /**
     * Metodo que sirve como bandera para intercambiar los archivos auxiliares
     * @param numArchivo Nombre del archivo auxiliar que sera cambiado
     * @return El nuevo nombre del archivo
     */
    public static String numFile(String numArchivo) {
        if (numArchivo.equals("arch1")) {
            numArchivo = "arch2";
        } else {
            numArchivo = "arch1";
        }
        return numArchivo;
    }
    /**
     * Metodo que crea el archivo con el nombre indicado por el usuario
     * @param nombre Nombre del archivo
     */
    public static void createFile(String nombre) {
        try {
            String ruta = ".\\files\\polifase\\" + nombre + ".txt";
            String contenido = "Contenido de ejemplo";
            File file = new File(ruta);
            // Si el archivo no existe es creado
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(contenido);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Metodo que insertara los bloques del archivos auxiliares al archivo final, pero de manera descendente
     * El algoritmo trabaja exactamente igual que juntarArchvioAsc
     * @param nombreAr Nombre del archivo final
     * @return true si se pudo leer los archivos auxiliares
     */
    public static boolean juntarArchviosDes(String nombreAr) {
        File auxFile1 = new File(".\\files\\polifase\\arch1.txt");
        File auxFile2 = new File(".\\files\\polifase\\arch2.txt");

        Queue<Double> q1 = new LinkedList<>();
        Queue<Double> q2 = new LinkedList<>();
        try {
            //se pasa el flujo al objeto scanner
            Scanner scAux1 = new Scanner(auxFile1);
            Scanner scAux2 = new Scanner(auxFile2);

            while (scAux1.hasNextLine() && scAux2.hasNextLine()) {
                String lineaAux1 = scAux1.nextLine();
                String lineaAux2 = scAux2.nextLine();

                Scanner delimitarAux1 = new Scanner(lineaAux1);
                Scanner delimitarAux2 = new Scanner(lineaAux2);

                delimitarAux1.useDelimiter("\\s*,\\s*");
                delimitarAux2.useDelimiter("\\s*,\\s*");
                while (delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while (delimitarAux2.hasNext()) {
                    q2.add(Double.parseDouble(delimitarAux2.next()));

                }
                while (!q1.isEmpty() && !q2.isEmpty()) {
                    if (q1.peek() > q2.peek()) {//Es lo unico en lo que cambia, el tipo de ordenamiento a insertar en el archivo principal
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    } else {
                        Polifase.writeInFile(q2.remove(), nombreAr, false);
                    }
                }

                while (!q1.isEmpty() && q2.isEmpty()) {
                    if (q1.size() == 1) {
                        Polifase.writeInFile(q1.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    }

                }
                while (q1.isEmpty() && !q2.isEmpty()) {
                    if (q2.size() == 1) {
                        Polifase.writeInFile(q2.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q2.remove(), nombreAr, false);
                    }

                }
            }
            while (scAux1.hasNextLine() && !scAux2.hasNextLine()) {
                String lineaAux1 = scAux1.nextLine();
                Scanner delimitarAux1 = new Scanner(lineaAux1);
                delimitarAux1.useDelimiter("\\s*,\\s*");
                while (delimitarAux1.hasNext()) {
                    q1.add(Double.parseDouble(delimitarAux1.next()));

                }
                while (!q1.isEmpty()) {
                    if (q1.size() == 1) {
                        Polifase.writeInFile(q1.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q1.remove(), nombreAr, false);
                    }

                }

            }
            while (!scAux1.hasNextLine() && scAux2.hasNextLine()) {
                String lineaAux2 = scAux1.nextLine();
                Scanner delimitarAux2 = new Scanner(lineaAux2);
                delimitarAux2.useDelimiter("\\s*,\\s*");
                while (delimitarAux2.hasNext()) {
                    q2.add(Double.parseDouble(delimitarAux2.next()));

                }
                while (!q2.isEmpty()) {
                    if (q2.size() == 1) {
                        Polifase.writeInFile(q2.remove(), nombreAr, true);
                    } else {
                        Polifase.writeInFile(q2.remove(), nombreAr, false);
                    }

                }

            }

            scAux1.close();
            scAux2.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    } 
    /**
     * Metodo que imprime los bloques de los archivos
     * @param nombre Nombre del archivo a examinar
     */
    public static void imprmirDatosArchvio(String nombre){
        try {
            File arch = new File(".\\files\\polifase\\"+nombre+".txt");
            Scanner contenido = new Scanner(arch); 
            System.out.println("\t\tContenido "+nombre);
            String imprimir;
            while(contenido.hasNext()){
                imprimir = contenido.next();
                System.out.println("\t\t\t"+imprimir);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("NOP");
        }
    }
    /**
     * Particion de la lista usando QuickSort ascendente
     * @param arr Arreglo a ordenar
     * @param low Valor izquierda de la lista
     * @param high Valor deracha de la lista
     * @return
     */
    public static int partition(Double arr[],int low, int high){
        double pivot =(double) arr[high];
        int i = (low-1);
        for (int j=low; j<high; j++){
            if (arr[j]<=pivot){
                i++;
                double temp = arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
        double temp = arr[i+1];
        arr[i+1]=arr[high];
        arr[high]= temp;
        return i+1;
    
    }
    /**
     * QuickSort ascendente 
     * @param arr Arreglo a ordenar
     * @param low Indice izquierdo del arreglo
     * @param high Indice derecho del arreglo
     */
    public static void sort(Double arr[], int low, int high){
        if (low<high){
            int pi = partition(arr,low,high);
            sort(arr,low,pi-1);
            sort(arr,pi+1,high);
        }
    }
    /**
     * Particion de la lista usando QuickSort descendente
     * @param arr Arreglo a ordenar
     * @param low Indice izquierdo del arreglo
     * @param high Indice derecho del arreglo
     * @return 
     */
    public static int partitionI(Double arr[],int low, int high){
        double pivot =(double) arr[high];
        int i = (low-1);
        for (int j=low; j<high; j++){
            if (arr[j]>=pivot){
                i++;
                double temp = arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
        double temp = arr[i+1];
        arr[i+1]=arr[high];
        arr[high]= temp;
        return i+1;
    
    }
    /**
     *  QuickSort descendente 
     * @param arr Arreglo a ordenar
     * @param low Indice izquierdo del arreglo
     * @param high Indice derecho del arreglo
     */
    public static void sortI(Double arr[], int low, int high){
        if (low<high){
            int pi = partitionI(arr,low,high);
            sortI(arr,low,pi-1);
            sortI(arr,pi+1,high);
        }
    }
    /**
     * Inserta los elementos que no completaron el bloque en el final del archivo
     * @param arr Arreglo con los elementos que no completaron el bloque
     * @param nombre Nombre del archivo a insertar los elementos
     */
    public static void InsertarSobrantes(Double arr[],String nombre){
        int lim=arr.length;
        boolean arch = false;//Bandera para indicar si es el ultimo elemento y asi mandar salto de linea
        for (int i=0;i<lim;i++){
            if (i==lim-1)
                arch=true;
            writeInFile(arr[i], nombre, arch);
        }
    }
}
    

