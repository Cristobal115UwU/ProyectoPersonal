/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectounoeda;
import java.io.*;
import java.util.*;

/**Contiene los métodos para ordenar las claves mediante el método de distribución.
 *
 * @author Equipo4EdaII
 */
public class Radix {
    private String archivoOrdenando;
    private ArrayList<Double> numeros = new ArrayList<>();
    
    /**Asigna el nombre del archivo que se encuentra ordenando en ese momento.
     * 
     * @param archivoOrdenando Nombre del archivo
     */
    public void setArchivoOrdenado(String archivoOrdenando){
        this.archivoOrdenando = archivoOrdenando;
    } 
    
    /**Regresa la lista donde se encuentran las claves del archivo leido.
     * 
     * @return ArrayList 
     */
    public ArrayList<Double> getNumeros(){
        return numeros;
    }
    
    /**Borra un archivo.
     * 
     * @param ruta Nombre del archivo a borrar dentro del directorio files\radix
     */
    public void borrarArchivo(String ruta){
        File file = new File(".\\files\\radix\\" + ruta + ".txt");
        if(file.exists())
            file.delete();
    }
    
    /**Vacía el contenido de la lista que contiene las claves del archivo.
     * 
     */
    public void vaciarLista(){
        numeros.clear();
    }
    
    /**Lee el contenido de un archivo, delimita las claves por comas y guarda los elementos en la lista "numeros". Borra el contenido si no es el archivo original.
     * 
     * @param ruta Ruta del archivo a leer
     * @return boolean
     * @throws IOException 
     */
    public boolean leerArchivo(String ruta) throws IOException {

            File file = new File(".\\files\\" + ruta + ".txt");
            if(!file.exists()){
                System.out.println("\tNo se encontró el archivo");
                return false;
            }
            	
            try {
                Scanner sc = new Scanner(file);

                while (sc.hasNextLine()) {
                    String linea = sc.nextLine();
                    Scanner delimitar = new Scanner(linea);			
                    delimitar.useDelimiter("\\s*,\\s*");
                    //String linea = sc.nextLine();
                    while(delimitar.hasNext()){
                        numeros.add(Double.parseDouble(delimitar.next()));
                    }
                }
                if(!ruta.equals("claves\\"+archivoOrdenando)){
                    FileWriter fw = new FileWriter(file);
                    fw.write("");
                    fw.close();
                }
                sc.close();
            } catch (FileNotFoundException e) {
                    e.printStackTrace();
            }
            return true;
    }
    
    /**Escribe el numero mandado al archivo especificado, si no existe lo crea.
     * 
     * @param ruta Ruta del archivo a escribir, sin extencion.
     * @param numero Numero de tipo double a introducir.
     */
    public void escribirArchivo(String ruta, double numero){
        try {
            File file = new File(".\\files\\radix\\" + ruta + ".txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.append(numero + ",");
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
}
