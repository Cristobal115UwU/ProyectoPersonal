/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectounoeda;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
/**
 *Esta clase nos genera un directorio con n numero de elementos, donde estos son aleatorios, del 0 a 9999.99
 * @author Equipo4EdaII
 */
public class GeneradorDeRandoms {
    /**
     * Crea el archivo y con un ciclo genera n numero de claves
     * @return Si fue exitosa la creacion del directorio 
     */
    public static boolean generateFileWithRands(){
        Scanner sc = new Scanner(System.in);
        String nombreArch;
        int numClaves;
        System.out.println("\tComo se va a llamar el archivo?");
        System.out.print("\t-->");
        nombreArch = sc.nextLine();
        if(nombreArch.equals("Tista")){
            System.out.println("EL NOMBRE TISTA ESTA BANEADO POR REPROBAR A LOS ALUMNOS");
            return false;
        }
        System.out.println("\tCuantas claves va a tener?");
        System.out.print("\t-->");
        numClaves = sc.nextInt();
        nombreArch+=numClaves;
        if(createFile(nombreArch) == false){
            System.out.println("Ya existe ese archivo");
            return true;
        }
        for(int i = 0 ; i < numClaves ; i++){
            writeInFile(generateValue(),nombreArch);
        }
        System.out.println("\tSe creó el archivo con "+numClaves+" claves"+"\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\claves\\"+nombreArch+".txt");
        return true;
    }
    
    /**
     * Metodo para escribir una clave en un archivo
     * @param num Clave a escribir en el archivo
     * @param nombre Nombre del Archivo donde se escribiran las claves
     */
    public static void writeInFile(Double num, String nombre) {
        FileWriter flwriter = null;
        try {
            flwriter = new FileWriter(".\\files\\claves\\"+nombre+".txt",true);
            BufferedWriter bfwriter = new BufferedWriter(flwriter); //Apertura arhivo con claves
            bfwriter.write(num+","); //Escribe el numero con una coma para que mas elementos del bloque sean escritos            
            bfwriter.close();
            flwriter.close();
        } catch (IOException e) {
                System.out.println("Unable to write randoms");
        } 
    }
    /**
     * Metodo que genera claves con dos decimales y entre 0 y 9999
     * @return Clave generada aleatoriamente 
     */
    public static Double generateValue( ) {
        Random rand = new Random();
        final double dbl= ((rand == null ? new Random() : rand).nextDouble() * (9999 - 0));
       // String valor = ; 
        return Double.parseDouble(String.format("%." + 2 + "f", dbl));

    }
    /**
     * Metodo para crear un archivo que contendra las claves
     * @param nombre Nombre que se le asignara al archivo
     * @return Si fue existoso la creación del archivo
     */
    public static boolean createFile(String nombre){
        try {
            String ruta = ".\\files\\claves\\"+nombre+".txt";
            File file = new File(ruta);
            
            if (!file.exists()) {
                file.createNewFile();
                return true;
            }else{
                System.out.println("\tEL ARCHIVO YA EXISTE");
                return false;
            }
            
        } catch (Exception e) {
           
        }
        return false;
    }
}
