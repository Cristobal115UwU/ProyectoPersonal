/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectounoeda;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *Entrada del codigo
 * @author Equipo4EdaII
 */
public class ProyectoUnoEDA {
    /**
     * Atributo que representará el nombre del archivo ustilizado
     */
    public static String archivo;

    /**
     * Entrada al programa
     * @param args
     * @throws IOException 
     */

    public static void main(String[] args) throws IOException {
        boolean activo = true;
        while (activo) {
            int eresante;
            Scanner sc = new Scanner(System.in);
            System.out.println("\t*****************************************");
            System.out.println("\tINGRESE LA OPCIÓN DE SU AGRADO");
            System.out.println("\t1.-Crear Nuevo Archivo con Claves");
            System.out.println("\t2.-Ordenar Archivo por Polifase");
            System.out.println("\t3.-Ordenar Archivo por Mezcla Equilibrada");
            System.out.println("\t4.-Ordenar Archivo por Distribucion Radix");
            System.out.println("\t5.-Salir");
            System.out.println("\t*****************************************");
            do {
                System.out.print("\t-->");
                eresante = sc.nextInt();
            } while (eresante < 0 || eresante > 5);
            if (eresante != 5 && eresante != 1) {
                imprimirArchivosClaves();
                System.out.println("\tIntroduzca el nombre del archivo que quiere ordenar,sin la extencion");
                sc.nextLine();
                System.out.print("\t-->");
                archivo = sc.nextLine();
                if(archivo.equals("Tista")){
                    System.out.println("EL NOMBRE TISTA ESTA BANEADO DEL PROGRAMA");
                    break;
                }
            }

            switch (eresante) {
                case 1:
                    boolean esterEgg = GeneradorDeRandoms.generateFileWithRands();
                    if(esterEgg == false ){
                        activo = false;
                    }
                    break;
                case 2:
                    boolean desi = ascenVSdescen();
                    System.out.print("\tCon cuantas claves quieres trabajar su bloque?\n\t-->");
                    int num = sc.nextInt();
                    System.out.println("");
                    if (desi) {
                        PolifaseA(archivo, num, "ascen");
                    } else {
                        PolifaseD(archivo, num, "descen");
                    }
                    break;
                case 3:
                    boolean des = ascenVSdescen();

                    if (des) {
                        MezclaEAsc();
                    } else {
                        MezclaEDes();
                    }

                    break;
                case 4:
                    radIX();
                    break;
                case 5:
                    activo = false;
            }
        }
    }
     /**
     * Metodo que imprimie la lista de los archivos con claves disponibles
     * *@return 
     */
    public static boolean imprimirArchivosClaves() {
        File dir = new File(".\\files\\claves");
        String[] ficheros = dir.list();
        if (ficheros == null) {
            System.out.println("\tNo hay ficheros en el directorio especificado");
        } else {
            System.out.println("\t--------------------------");
            System.out.println("\tARCHIVOS CON CLAVES");
            for (String fichero : ficheros) {
                System.out.println("\t\t"+fichero);
            }
            System.out.println("\t--------------------------");
        }
        return true;
    }
    /**
     * Metodo para evaliar si se va a relaizar ordenamiento ascendente o descendente
     * @return true si es ascendente o false si es descendente
     */
    public static boolean ascenVSdescen() {
        Scanner sc = new Scanner(System.in);
        int des;
        do {
            System.out.println("\tIngrese que ordenamiento quiere hacer");
            System.out.println("\t1.-Ascendente");
            System.out.println("\t2.-Descendente");
            System.out.print("\t-->");
            des = sc.nextInt();

        } while (des > 2 || des < 1);
        if (des == 1) {
            return true;
        }
        return false;

    }
    /**
     * Metodo para ordenar por mezcla equilibrada ascendente
     */
    public static void MezclaEAsc() {

        String archivoGuardar = "ordenado-ascen-" + archivo;

        MezclaEquilibrada.createFile(archivoGuardar);
        boolean ordenado = false;
        int conta = 1;

        MezclaEquilibrada.borrarContAux();
        MezclaEquilibrada.leerArchivoPrincipalAsc(archivo);
        ordenado = MezclaEquilibrada.isOrdenado();
        while (ordenado == false) {
            System.out.println("\tITERACION " + (conta++));
            MezclaEquilibrada.imprmirDatosArchvio("arch1");
            MezclaEquilibrada.imprmirDatosArchvio("arch2");
            MezclaEquilibrada.borrarPrincipal(archivoGuardar);
            MezclaEquilibrada.juntarArchviosAsc(archivoGuardar);
            MezclaEquilibrada.imprmirDatosArchvio(archivoGuardar);
            MezclaEquilibrada.borrarContAux();
            MezclaEquilibrada.mezclarBloques(archivoGuardar);
            if (MezclaEquilibrada.isOrdenado() == true) {
                break;
            }

        }
        System.out.println("\n\tLas claves se han ordenado\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\mezclaEqui\\ordenado-ascen-" + archivo + ".txt");
    }
    /**
     * 
     *Metodo para ordenar por mezcla equilibrada descendente
     */
    public static void MezclaEDes() {
        String archivoGuardar = "ordenado-descen-" + archivo;

        MezclaEquilibrada.createFile(archivoGuardar);
        boolean ordenadoD = false;
        int conta = 1;

        MezclaEquilibrada.borrarContAux();
        MezclaEquilibrada.leerArchivoPrincipalDes(archivo);
        ordenadoD = MezclaEquilibrada.isOrdenado();
        while (ordenadoD == false) {
            System.out.println("\tITERACION " + (conta++));
            MezclaEquilibrada.imprmirDatosArchvio("arch1");
            MezclaEquilibrada.imprmirDatosArchvio("arch2");
            MezclaEquilibrada.borrarPrincipal(archivoGuardar);
            MezclaEquilibrada.juntarArchviosDes(archivoGuardar);
            MezclaEquilibrada.imprmirDatosArchvio(archivoGuardar);
            MezclaEquilibrada.borrarContAux();
            MezclaEquilibrada.mezclarBloques(archivoGuardar);
            if (MezclaEquilibrada.isOrdenado() == true) {
                break;
            }
        }
        System.out.println("\n\tLas claves se han ordenado\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\mezclaEqui\\ordenado-descen-" + archivo + ".txt");
    }
    /**
     * Metodo para ordenar por polifase ascendente
     * @param arch Nombre del Archivo
     * @param numero Numero de claves
     * @param orden Tipo  de ordenaje
     * @return
     * @throws IOException 
     */
    public static boolean PolifaseA(String arch, int numero, String orden) throws IOException {
        String archivoGuardar = "ordenado-" + arch + "-" + orden;

        Polifase.createFile(archivoGuardar);
        Boolean ordenado = false;
        int conta = 1;

        Polifase.borrarContAux();
        boolean apertura = Polifase.leerArchivoPrincipalAsc(arch, numero);
        if(apertura == false){
            return false;
        }
        while (ordenado == false) {
            System.out.println("\tITERACION " + (conta++));
            Polifase.imprmirDatosArchvio("arch1");
            Polifase.imprmirDatosArchvio("arch2");
            Polifase.borrarPrincipal(archivoGuardar);
            Polifase.juntarArchviosAsc(archivoGuardar);
            Polifase.imprmirDatosArchvio(archivoGuardar);
            Polifase.borrarContAux();
            Polifase.mezclarBloquesAsc(archivoGuardar);
            if (ordenado = Polifase.isOrdenado()) {
                break;
            }
        }
        System.out.println("\n\tLas claves se han ordenado\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\polifase\\ordenado-" + archivo + "-" + orden + ".txt");
        return true;
    }
    /**
     * Metodo para ordenar por polifase ascendente
     * @param arch Nombre del Archivo
     * @param numero Numero de claves
     * @param orden Tipo  de ordenaje
     * @return
     * @throws IOException 
     */
    public static boolean PolifaseD(String arch, int numero, String orden) throws IOException {
        String archivoGuardar = "ordenado-" + arch + "-" + orden;

        Polifase.createFile(archivoGuardar);
        Boolean ordenado = false;
        int conta = 1;

        Polifase.borrarContAux();
        boolean apertura = Polifase.leerArchivoPrincipalDes(arch, numero);
        if(apertura == false){
            return false;
        }
        while (ordenado == false) {
            System.out.println("\tITERACION " + (conta++));
            Polifase.imprmirDatosArchvio("arch1");
            Polifase.imprmirDatosArchvio("arch2");
            Polifase.borrarPrincipal(archivoGuardar);
            Polifase.juntarArchviosDes(archivoGuardar);
            Polifase.imprmirDatosArchvio(archivoGuardar);
            Polifase.borrarContAux();
            Polifase.mezclarBloquesAsc(archivoGuardar);
            if (ordenado = Polifase.isOrdenado()) {
                break;
            }
        }
        System.out.println("\n\tLas claves se han ordenado\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\polifase\\ordenado-" + archivo + "-" + orden + ".txt");
        return true;
    }
    /**
     * Inicia el método por distribución: Separa los elementos del archivo original dependiendo del valor del digito a analizar según lo especifique el primer ciclo for, imprime el resultado en el archivo final e indica el lugar donde se guardó.
     * @throws IOException 
     */
    public static void radIX() throws IOException {
        Scanner sc = new Scanner(System.in);
        int res, it = 0, opt;

        ArrayList<Double> numeros;
        Radix radixEx = new Radix();

        radixEx.setArchivoOrdenado(archivo);
        if (radixEx.leerArchivo("claves\\" + archivo)) {
            System.out.println("\n\tQue tipo de ordenamiento quiere?\n\t1.-Ascendente\n\t2.-Descendente");
            System.out.print("\t-->");
            opt = sc.nextInt();
            System.out.println("");
            numeros = radixEx.getNumeros();
            for (double i = 0.01; i <= 1000; i *= 10) {
                System.out.println("\n\tIteracion #" + it);
                System.out.print("\t");
                for (double elemento : numeros) {
                    System.out.print(elemento + " ");
                    //double res = (elemento%(i * 10))/ i;
                    res = (int) (elemento % (i * 10) / i);
                    if (i == 0.01) {
                        res++;
                    }
                    if (res == 10) {
                        res = 0;
                    }
                    radixEx.escribirArchivo("colas\\cola" + res, elemento);
                }
                radixEx.vaciarLista();
                if (opt == 1) {
                    for (int j = 0; j < 10; j++) {
                        radixEx.leerArchivo("radix\\colas\\cola" + j);
                    }
                } else {
                    for (int j = 9; j >= 0; j--) {
                        radixEx.leerArchivo("radix\\colas\\cola" + j);
                    }
                }
                numeros = radixEx.getNumeros();
                System.out.println();
                it++;
            }
            radixEx.borrarArchivo("ordenado-" + archivo);
            for (double elemento : numeros) {
                radixEx.escribirArchivo("ordenado-" + archivo, elemento);
            }
            System.out.println("\n\tLas claves se han ordenado\n\tRuta del archivo: " + System.getProperty("user.dir") + "\\files\\radix\\ordenado-" + archivo + ".txt");
        }

    }
}
